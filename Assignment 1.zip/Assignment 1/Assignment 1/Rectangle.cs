﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    class Rectangle : Parallelogram
    {
        public override void CalculateArea()
        {
            System.Console.WriteLine("CalculateArea : Rectangle\n");
        }

    }
}
