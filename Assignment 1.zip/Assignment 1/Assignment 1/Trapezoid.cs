﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    class Trapezoid : Quadrilateral
    {
        public override void CalculateArea()
        {
            System.Console.WriteLine("CalculateArea : Trapezoid\n");
        }
    }
}
